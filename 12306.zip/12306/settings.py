# !/usr/bin/env python
# -*- coding:utf-8 -*-
__author__ = 'Arvin'

TRAIN_DATE = '2018-08-07'
BACK_TRAIN_DATE = '2018-07-16'
FROM_STATION = '成都'
TO_STATION = '长沙'
SET = 23 #23代表的是软卧