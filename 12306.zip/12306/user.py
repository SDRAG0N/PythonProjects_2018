# !/usr/bin/env python
# -*- coding:utf-8 -*-
__author__ = '强子'
# user='13548612815'
# pwd='whw199508157276'

user = 'cai345408904'
pwd = 'cai15928021496'

codeUser = 'cai345408904'
codePwd = 'qiangzi..'